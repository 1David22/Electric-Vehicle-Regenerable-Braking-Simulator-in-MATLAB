function [v_new, SoC_new, current_power, forces] = EV_Physics(v_old, SoC_old, throttle, brake, dt, regen_eff_input)
    % EV_PHYSICS v3 - Added Dead Battery Logic
    % If SoC <= 0, the car ignores throttle input.

    % --- 1. CONSTANTS ---
    mass = 1800;     
    rho = 1.225;     
    Cd = 0.29;       
    A = 2.2;         
    Max_Thrust = 3500; 
    Max_Regen = 3000;  
    
    Motor_Eff = 0.92;  
    Gen_Eff = regen_eff_input; 
    
    % --- 2. INPUT LOGIC (DEAD BATTERY CHECK) ---
    real_throttle = throttle;
    
    % If battery is empty (or negative) AND we are trying to drive...
    if SoC_old <= 0 && throttle > 0
        real_throttle = 0; % Cut power to motor
    end
    
    % --- 3. CALCULATE FORCES ---
    F_drag = 0.5 * rho * Cd * A * (v_old^2);
    F_roll = 0.015 * mass * 9.81;
    
    F_motor = real_throttle * Max_Thrust;
    F_brake = brake * Max_Regen;
    
    if v_old > 0
        F_net = F_motor - F_brake - F_drag - F_roll;
    else
        % If stopped, drag/roll can't pull backward
        F_net = max(0, F_motor - F_brake); 
    end
    
    % --- 4. UPDATE MOTION ---
    accel = F_net / mass;
    v_new = v_old + (accel * dt);
    
    % Prevent reversing or negative speed artifacts
    if v_new < 0, v_new = 0; end
    
    % --- 5. ENERGY CALCULATION ---
    % Only consume power if we actually have throttle force
    if F_motor > 10 
        current_power = (F_motor * v_old) / Motor_Eff + 250; 
    elseif F_brake > 10 && v_old > 0.5
        current_power = -1 * (F_brake * v_old) * Gen_Eff;
    else
        current_power = 250; % Idle drain (lights/AC)
    end
    
    % Update Battery
    energy_change = current_power * dt;
    SoC_new = SoC_old - energy_change;
    
    % Hard floor at 0 for display (physics logic handled above)
    if SoC_new < 0, SoC_new = 0; end
    
    forces.drag = F_drag;
end