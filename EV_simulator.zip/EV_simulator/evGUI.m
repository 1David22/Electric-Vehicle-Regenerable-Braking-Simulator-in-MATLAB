function evGUI
    % EV_GUI_PRO v7 (FINAL) - Added PDF Documentation Button
    % Requires: EV_Physics.m (v3), ev_powertrain.jpg, and Project_Report.pdf
    
    % --- THEME CONFIGURATION ---
    Theme.Bg       = [0.10 0.11 0.14];
    Theme.Panel    = [0.16 0.18 0.22];
    Theme.Accent   = [0.00 0.70 1.00]; 
    Theme.Regen    = [0.00 0.90 0.40]; 
    Theme.Warn     = [1.00 0.30 0.30]; 
    Theme.Text     = [0.95 0.95 0.95]; 
    Theme.SubText  = [0.70 0.70 0.70]; 
    Theme.Grid     = [0.40 0.40 0.40]; 
    
    % --- MAIN SETUP ---
    close all; clc;
    global stopSim; stopSim = false; 
    
    fig = figure('Name', 'EV REGENERATIVE BRAKING SIMULATOR', ...
                 'NumberTitle', 'off', 'Position', [50, 50, 1200, 750], ...
                 'Color', Theme.Bg, 'MenuBar', 'none', 'Resize', 'on');

    % --- HEADER ---
    uipanel('Parent', fig, 'Position', [0 0.94 1 0.06], ...
            'BackgroundColor', Theme.Panel, 'BorderType', 'none');
    uicontrol('Parent', fig, 'Style', 'text', 'String', ' EV REGENERATIVE BRAKING SIMULATOR', ...
              'Units', 'normalized', 'Position', [0.01 0.935 0.5 0.05], ...
              'BackgroundColor', Theme.Panel, 'ForegroundColor', Theme.Accent, ...
              'FontSize', 15, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');

    % --- LEFT CARD: DRIVER INPUTS ---
    panelControl = uipanel('Parent', fig, 'BackgroundColor', Theme.Panel, ...
                           'Position', [0.02 0.05 0.28 0.87], ...
                           'BorderType', 'line', 'HighlightColor', [0.3 0.3 0.3], ...
                           'Title', 'DRIVER CONTROLS', 'TitlePosition', 'centertop', ...
                           'ForegroundColor', Theme.SubText, 'FontSize', 11);

    % 1. IMAGE AREA (35% Height)
    uicontrol('Parent', panelControl, 'Style', 'text', 'String', 'POWERTRAIN DIAGRAM', ...
              'Units', 'normalized', 'Position', [0.05 0.94 0.9 0.03], ...
              'BackgroundColor', Theme.Panel, 'ForegroundColor', Theme.Accent, ...
              'FontSize', 9, 'FontWeight', 'bold');
              
    axImage = axes('Parent', panelControl, 'Position', [0.02 0.58 0.96 0.35], ...
                   'Color', 'k', 'XColor', 'none', 'YColor', 'none');
    if exist('evRegen.png', 'file')
        img = imread('evRegen.png'); 
        imshow(img, 'Parent', axImage); axis(axImage, 'off');
    else
        text(0.5, 0.5, 'IMAGE NOT FOUND', 'Parent', axImage, 'Color', 'w', 'HorizontalAlignment', 'center');
    end

    % 2. CONTROLS
    function createSliderGroup(parent, label, yPos, color, tag)
        uicontrol('Parent', parent, 'Style', 'text', 'String', label, ...
                  'Units', 'normalized', 'Position', [0.05 yPos+0.035 0.9 0.03], ...
                  'BackgroundColor', Theme.Panel, 'ForegroundColor', color, ...
                  'FontSize', 11, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
        uicontrol('Parent', parent, 'Style', 'slider', 'Min', 0, 'Max', 1, ...
                  'Units', 'normalized', 'Position', [0.05 yPos 0.9 0.04], ...
                  'Tag', tag, 'BackgroundColor', Theme.Panel);
    end
    createSliderGroup(panelControl, 'ACCELERATOR', 0.45, Theme.Accent, 'sldThrottle');
    createSliderGroup(panelControl, 'BRAKE PEDAL (REGEN)', 0.32, Theme.Warn, 'sldBrake');
    
    % 3. MOTOR SELECTOR
    uicontrol('Parent', panelControl, 'Style', 'text', 'String', 'MOTOR CONFIGURATION', ...
              'Units', 'normalized', 'Position', [0.05 0.22 0.9 0.03], ...
              'BackgroundColor', Theme.Panel, 'ForegroundColor', Theme.Text, ...
              'FontSize', 11, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
              
    uicontrol('Parent', panelControl, 'Style', 'popupmenu', ...
              'String', {'STANDARD Induction (75% Regen Eff)', ...
                         'PERFORMANCE Permanent Magnet (85% Regen Eff)', ...
                         'TRACK Carbon-Sleeved (95% Regen Eff)'}, ...
              'Units', 'normalized', 'Position', [0.05 0.17 0.9 0.05], ...
              'Tag', 'popMotor', 'FontSize', 10, 'BackgroundColor', Theme.SubText);

    % 4. ACTION BUTTONS (DOCUMENTATION + START)
    % Documentation Button
    uicontrol('Parent', panelControl, 'Style', 'pushbutton', ...
              'String', 'OPEN PROJECT DOCUMENTATION (PDF)', ...
              'Units', 'normalized', 'Position', [0.05 0.125 0.9 0.04], ... 
              'BackgroundColor', Theme.Grid, 'ForegroundColor', 'white', ...
              'FontSize', 10, 'FontWeight', 'bold', ...
              'Callback', @(src, event) open('EV_Documentation.pdf'));

    % Start Button
    btnStart = uicontrol('Parent', panelControl, 'Style', 'pushbutton', ...
                         'String', 'START TEST DRIVE', ...
                         'Units', 'normalized', 'Position', [0.05 0.04 0.9 0.08], ...
                         'BackgroundColor', Theme.Accent, 'ForegroundColor', 'black', ...
                         'FontSize', 13, 'FontWeight', 'bold', 'Callback', @startSimulation);

    % --- RIGHT CARD: TELEMETRY ---
    panelGraph = uipanel('Parent', fig, 'BackgroundColor', Theme.Panel, ...
                         'Position', [0.32 0.05 0.66 0.87], ...
                         'BorderType', 'line', 'HighlightColor', [0.3 0.3 0.3], ...
                         'Title', 'LIVE TELEMETRY', 'TitlePosition', 'centertop', ...
                         'ForegroundColor', Theme.SubText, 'FontSize', 11);

    % DASHBOARD TEXT
    uicontrol('Parent', panelGraph, 'Style', 'text', 'String', 'CURRENT VELOCITY', ...
              'Units', 'normalized', 'Position', [0.05 0.88 0.3 0.03], ...
              'BackgroundColor', Theme.Panel, 'ForegroundColor', Theme.SubText, 'FontSize', 10);
              
    txtSpeed = uicontrol('Parent', panelGraph, 'Style', 'text', 'String', '0', ...
                         'Units', 'normalized', 'Position', [0.05 0.72 0.20 0.16], ...
                         'BackgroundColor', Theme.Panel, 'ForegroundColor', Theme.Text, ...
                         'FontSize', 54, 'FontWeight', 'bold', 'HorizontalAlignment', 'right');
                         
    uicontrol('Parent', panelGraph, 'Style', 'text', 'String', 'km/h', ...
              'Units', 'normalized', 'Position', [0.26 0.76 0.1 0.05], ...
              'BackgroundColor', Theme.Panel, 'ForegroundColor', Theme.Accent, 'FontSize', 16, 'FontWeight', 'bold');

    txtPower = uicontrol('Parent', panelGraph, 'Style', 'text', 'String', 'VEHICLE STOPPED', ...
                         'Units', 'normalized', 'Position', [0.55 0.80 0.4 0.08], ...
                         'BackgroundColor', [0.1 0.1 0.1], 'ForegroundColor', Theme.SubText, ...
                         'FontSize', 16, 'FontWeight', 'bold');

    % BATTERY BAR
    uicontrol('Parent', panelGraph, 'Style', 'text', 'String', 'BATTERY STATE OF CHARGE', ...
              'Units', 'normalized', 'Position', [0.55 0.74 0.4 0.03], ...
              'BackgroundColor', Theme.Panel, 'ForegroundColor', Theme.SubText, 'HorizontalAlignment', 'left');
              
    uipanel('Parent', panelGraph, 'Position', [0.55 0.70 0.4 0.04], 'BackgroundColor', [0.08 0.08 0.08], 'BorderType', 'line', 'HighlightColor', [0.3 0.3 0.3]);
    barBatt = uipanel('Parent', panelGraph, 'Position', [0.55 0.70 0.4 0.04], ...
                      'BackgroundColor', Theme.Accent, 'BorderType', 'none'); 
    
    % --- PLOTS ---
    axSpeed = axes('Parent', panelGraph, 'Position', [0.08 0.44 0.88 0.20], ...
                   'Color', [0.08 0.08 0.08], 'XColor', Theme.Text, 'YColor', Theme.Text, ...
                   'GridColor', Theme.Grid, 'GridAlpha', 0.5, 'FontSize', 11, 'LineWidth', 1.1);
    grid(axSpeed, 'on'); 
    ylabel(axSpeed, 'Speed (m/s)', 'FontWeight', 'bold');
    xlabel(axSpeed, 'Time (s)', 'FontWeight', 'bold'); 
    title(axSpeed, 'VELOCITY HISTORY', 'Color', Theme.SubText, 'FontWeight', 'normal');
    lineSpeed = animatedline('Parent', axSpeed, 'Color', Theme.Accent, 'LineWidth', 3);

    axBatt = axes('Parent', panelGraph, 'Position', [0.08 0.10 0.88 0.20], ...
                  'Color', [0.08 0.08 0.08], 'XColor', Theme.Text, 'YColor', Theme.Text, ...
                   'GridColor', Theme.Grid, 'GridAlpha', 0.5, 'FontSize', 11, 'LineWidth', 1.1);
    grid(axBatt, 'on'); 
    ylabel(axBatt, 'Energy (Joules)', 'FontWeight', 'bold');
    xlabel(axBatt, 'Time (s)', 'FontWeight', 'bold'); 
    title(axBatt, 'BATTERY ENERGY TREND', 'Color', Theme.SubText, 'FontWeight', 'normal');
    lineBatt = animatedline('Parent', axBatt, 'Color', Theme.Regen, 'LineWidth', 3);

    % --- SIMULATION LOOP ---
    function startSimulation(~, ~)
        stopSim = false;
        set(btnStart, 'Enable', 'off', 'String', 'SIMULATION ACTIVE...');
        
        v = 0; 
        battery_max = 1000000; 
        battery_energy = 1000000; % Start FULL (100%)
        
        dt = 0.1; time = 0;
        clearpoints(lineSpeed); clearpoints(lineBatt);
        
        hThr = findobj(fig, 'Tag', 'sldThrottle');
        hBrk = findobj(fig, 'Tag', 'sldBrake');
        hPop = findobj(fig, 'Tag', 'popMotor'); 
        
        while ishandle(fig) && ~stopSim
            % 1. Inputs
            thr = get(hThr, 'Value');
            brk = get(hBrk, 'Value');
            motorChoice = get(hPop, 'Value');
            
            switch motorChoice
                case 1, regen_eff_val = 0.75;
                case 2, regen_eff_val = 0.85;
                case 3, regen_eff_val = 0.95;
            end
            
            % 2. Physics Call
            [v, battery_energy, pwr, ~] = EV_Physics(v, battery_energy, thr, brk, dt, regen_eff_val);
            
            % 3. Check for Dead Stop
            if battery_energy <= 0 && v < 0.1
                set(txtPower, 'String', '❌ TEST OVER: DEAD BATTERY', 'ForegroundColor', Theme.Warn);
                set(btnStart, 'String', 'TEST FINISHED');
                set(barBatt, 'BackgroundColor', [0.2 0 0]);
                break; 
            end
            
            % 4. Visual Updates
            set(txtSpeed, 'String', num2str(round(v*3.6))); 
            
            if battery_energy <= 0
                set(txtPower, 'String', '⚠ BATTERY EMPTY (COASTING)', 'ForegroundColor', Theme.Warn);
                set(barBatt, 'BackgroundColor', Theme.Warn);
            elseif pwr > 1000
                set(txtPower, 'String', '⚡ DRAINING POWER', 'ForegroundColor', Theme.Warn);
                set(barBatt, 'BackgroundColor', Theme.Warn);
            elseif pwr < -100
                motorNames = {'STANDARD', 'PERF', 'TRACK'};
                set(txtPower, 'String', ['♻ REGEN (' motorNames{motorChoice} ')'], 'ForegroundColor', Theme.Regen);
                set(barBatt, 'BackgroundColor', Theme.Regen);
            else
                set(txtPower, 'String', 'COASTING / IDLE', 'ForegroundColor', Theme.SubText);
                set(barBatt, 'BackgroundColor', Theme.Accent);
            end
            
            battPct = max(0, min(1, battery_energy / battery_max));
            set(barBatt, 'Position', [0.55 0.70 (0.4 * battPct) 0.04]);
            
            addpoints(lineSpeed, time, v);
            addpoints(lineBatt, time, battery_energy);
            
            % Axis Scrolling
            timeWindow = 30;
            xlim(axSpeed, [max(0, time-timeWindow), max(timeWindow, time)]);
            xlim(axBatt, [max(0, time-timeWindow), max(timeWindow, time)]);
            
            time = time + dt;
            pause(dt/2); drawnow limitrate;
        end
        if ishandle(fig), set(btnStart, 'Enable', 'on', 'String', 'START NEW TEST'); end
    end
end